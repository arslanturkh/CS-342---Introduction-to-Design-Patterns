require_relative "Meadow"

def main
  Meadow.instance.startCycle()
end

main