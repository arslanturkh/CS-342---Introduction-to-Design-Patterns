
class Ant
  attr_accessor :experience, :type, :hill_name
  def initialize()
    @type = nil
    @hill_name = nil
    @experience = 0
  end
end